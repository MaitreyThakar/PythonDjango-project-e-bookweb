from django.shortcuts import render,redirect

from ProductApp.models import CategoryModel,ProductModel

# Create your views here.
def HomeView(request):
    if 'userId' in request.session.keys():
        categoryData = CategoryModel.objects.all()
        print(categoryData)
        return render(request,'home.html',{'categoryKey':categoryData})
    else:
        return redirect('login')

def ProductView(request):
    if 'userId' in request.session.keys():
        productData = ProductModel.objects.all()
        return render(request,'product.html',{'productData':productData})
    else:
        return redirect('login')

def LogoutView(request):
    #return render(request,'login.html')
    del request.session['userId']
    return redirect('login')